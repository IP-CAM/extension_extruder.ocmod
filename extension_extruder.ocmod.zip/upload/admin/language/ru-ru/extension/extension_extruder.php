<?php
$_['text_no_code']           = 'Не указан code расширения!';
$_['error_permission']       = 'У Вас нет прав для выгрузки расширений!';
$_['text_extrude_extension'] = 'Экспорт расширения';