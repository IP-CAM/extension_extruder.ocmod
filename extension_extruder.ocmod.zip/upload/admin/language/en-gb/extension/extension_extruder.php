<?php
$_['text_no_code']           = 'No module code provided!';
$_['error_permission']       = 'Warning: You do not have permission to extrude modules!';
$_['text_extrude_extension'] = 'Extrude extension';